import React from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import InputAdornment from "@mui/material/InputAdornment";
import IconButton from "@mui/material/IconButton";
import axios from "axios";
import Navbar from "../layout/Navbar";
import { useSnackbar } from "notistack";
import { Navigate } from "react-router-dom";

const Login = () => {
  const { enqueueSnackbar } = useSnackbar();

  const [showPassword, setShowPassword] = React.useState(false);
  const [data, setData] = React.useState([]);
  const [result, setResult] = React.useState(false);

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const [loginData, setLoginData] = React.useState({
    email: "",
    password: "",
  });

  const [errors, setErrors] = React.useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setLoginData((prev) => ({
      ...prev,
      [name]: value,
    }));

    // Reset the error for the specific field when the user changes the input
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validateForm = () => {
    let isValid = true;
    const newErrors = { ...errors };

    // Validate each field and update the errors state
    if (loginData.email.trim() === "") {
      newErrors.email = "Email is required";
      isValid = false;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(loginData.email)) {
      newErrors.email = "Invalid email format";
      isValid = false;
    }

    if (loginData.password.trim() === "") {
      newErrors.password = "Password is required";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleOnSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      // If form validation fails, do not submit the form
      return;
    }

    localStorage.setItem("DB data", JSON.stringify(data));
    const index = data.findIndex((x) => x.email === loginData.email);

    if (index !== -1) {
      const given = loginData.password || null;
      const dataResult = data[index].password === given;
      setResult(dataResult);

      if (dataResult) {
        console.log("success");
        localStorage.setItem("userToken", JSON.stringify(loginData.email));
        enqueueSnackbar("Successfully logged in!!!", { variant: "success" });
      } else {
        enqueueSnackbar("Wrong Password, Please try again!!", {
          variant: "error",
        });
      }
    } else {
      enqueueSnackbar("User not found, Please Register", { variant: "error" });
    }
  };

  React.useEffect(() => {
    axios.get("http://localhost:4000/getUser").then((response) => {
      const data = response.data.db;
      setData(data);
    });
  }, [data]);

  return (
    <div>
      <Navbar />
      {result ? <Navigate to="/userData" /> : null}
      <div className="shadow-md p-5 w-96 mx-auto mt-10 flex items-center justify-center h-full">
        <form onSubmit={handleOnSubmit}>
          <h1 className="text-center font-semibold text-blue-800 text-2xl">
            Login
          </h1>
          <TextField
            margin="dense"
            label="Email"
            name="email"
            onChange={handleChange}
            variant="outlined"
            fullWidth
            error={!!errors.email}
            helperText={errors.email}
          />
          <TextField
            margin="dense"
            label="Password"
            onChange={handleChange}
            name="password"
            type={showPassword ? "text" : "password"}
            variant="outlined"
            fullWidth
            error={!!errors.password}
            helperText={errors.password}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton onClick={togglePasswordVisibility} edge="end">
                    {showPassword ? <Visibility /> : <VisibilityOff />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
          <div className="my-5">
            <Button variant="contained" color="primary" fullWidth type="submit">
              Login
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
