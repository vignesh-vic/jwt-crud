import React, { useState, useRef, useMemo } from "react";
import { AgGridReact } from "ag-grid-react"; // the AG Grid React Component
import "ag-grid-community/styles/ag-grid.css"; // Core grid CSS, always needed
import "ag-grid-community/styles/ag-theme-alpine.css"; // Optional theme CSS
import axios from "axios";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import Button from "@mui/material/Button";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import Select from "@mui/material/Select";
import Checkbox from "@mui/material/Checkbox";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormLabel from "@mui/material/FormLabel";
import Navbar from "../layout/Navbar";

const HomeScreen = () => {
  //dialog
  const [open, setOpen] = React.useState(false);

  const gridRef = useRef(); // Optional - for accessing Grid's API
  const [rowData, setRowData] = useState(); // Set rowData to Array of Objects, one Object per Row

  const [index, setIndex] = useState(-1);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  // DefaultColDef sets props common to all Columns
  const defaultColDef = useMemo(
    () => ({
      sortable: true,
    }),
    []
  );

  //fetchEmail
  const jsonData = localStorage.getItem("userToken");
  const getEmail = JSON.parse(jsonData);
  console.log(getEmail);

  const URL = "http://localhost:4000";

  React.useEffect(() => {
    axios
      .get(`${URL}/getUser`)
      .then((response) => {
        const userData = response.data.db;
        const rowDataID = userData.findIndex((item) => item.email === getEmail);
        setIndex(rowDataID);
        setRowData(userData);
      })
      .catch((error) => {
        console.log(error.message);
      });
  });

  //edit user
  const handleEditButton = () => {
    if (index !== -1) {
      if (getEmail === rowData[index]?.email) {
        if (
          rowData[index].role === "Super Admin" ||
          rowData[index].role === "Owner"
        ) {
          return true;
        } else {
          return false;
        }
      }
    } else {
      return false;
    }
  };

  const handleEdit = (data) => {
    axios.patch(`${URL}/updateUser/:${data._id}`, data).then((res) => {});
  };

  const handleDelete = (data) => {
    axios
      .delete(`${URL}/deleteUser/${data._id}`, data)
      .then((res) => {
        console.log(data);
        setRowData((prevRowData) =>
          prevRowData.filter((user) => user._id !== data._id)
        );
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Each Column Definition results in one Column.
  const columnDefs = [
    { field: "firstName", filter: true },
    { field: "lastName", filter: true },
    { field: "email", filter: true },
    { field: "gender", filter: true },
    { field: "role", filter: true },
    { field: "age", filter: true },
    { field: "active", filter: true },
    handleEditButton() && {
      field: "Edit",
      headerName: "Edit",
      cellRenderer: editRenderer,
    },
    handleEditButton() && {
      field: "delete",
      headerName: "Delete",
      cellRenderer: deleteRenderer,
    },
  ];

  //delete render
  function deleteRenderer(params) {
    return (
      <div>
        <IconButton
          aria-label="delete"
          className="p-3"
          color="error"
          onClick={() => handleDelete(params.data, params.data.id)}
        >
          <DeleteIcon />
        </IconButton>
      </div>
    );
  }

  //delete render
  function editRenderer(params) {
    return (
      <div>
        <IconButton
          aria-label="delete"
          className="p-3"
          color="primary"
          onClick={() => handleClickOpen()}
        >
          <EditIcon />
        </IconButton>
      </div>
    );
  }

  console.log(rowData);
  console.log(index);
  return (
    <div>
      <Navbar />
      {/* On div wrapping Grid a) specify theme CSS Class Class and b) sets Grid size */}
      <div
        className="ag-theme-alpine-dark"
        style={{ width: "max-width", height: 800, margin: "10px" }}
      >
        <Dialog open={open} onClose={handleClose}>
          <DialogTitle>Edit User</DialogTitle>
          <DialogContent>
            <DialogContentText>
              To edit the user you should be owner to it or super admin
            </DialogContentText>
            <TextField
              margin="dense"
              label="First Name"
              name="firstName"
              variant="outlined"
              fullWidth
            />
            <TextField
              margin="dense"
              label="Last Name"
              variant="outlined"
              name="lastName"
              fullWidth
            />
            <TextField
              margin="dense"
              label="Email"
              name="email"
              type="email"
              variant="outlined"
              fullWidth
            />

            <FormControl fullWidth margin="dense">
              <InputLabel>Role</InputLabel>
              <Select name="role" label="Active">
                <MenuItem value="Owner">Owner</MenuItem>
                <MenuItem value="Super Admin">Super Admin</MenuItem>
                <MenuItem value="Admin">Admin</MenuItem>
                <MenuItem value="Manager">Manager</MenuItem>
              </Select>
            </FormControl>

            <div className="my-2">
              <InputLabel>Active status</InputLabel>
              <div>
                <Checkbox name="active" color="success" />
                <label>Active</label>
              </div>
            </div>
            <TextField
              margin="dense"
              label="Age"
              type="number"
              name="age"
              variant="outlined"
              fullWidth
            />
            <FormControl margin="dense">
              <FormLabel id="demo-radio-buttons-group-label">Gender</FormLabel>
              <RadioGroup
                aria-labelledby="demo-radio-buttons-group-label"
                defaultValue="male"
                name="gender"
              >
                <FormControlLabel
                  value="female"
                  control={<Radio />}
                  label="Female"
                />
                <FormControlLabel
                  value="male"
                  control={<Radio />}
                  label="Male"
                />
                <FormControlLabel
                  value="other"
                  control={<Radio />}
                  label="Other"
                />
              </RadioGroup>
            </FormControl>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose} variant="contained" color="error">
              Cancel
            </Button>
            <Button onClick={handleEdit} variant="contained">
              Update
            </Button>
          </DialogActions>
        </Dialog>
        <AgGridReact
          ref={gridRef} // Ref for accessing Grid's API
          rowData={rowData} // Row Data for Rows
          columnDefs={columnDefs} // Column Defs for Columns
          defaultColDef={defaultColDef} // Default Column Properties
          animateRows={true} // Optional - set to 'true' to have rows animate when sorted
          rowSelection="multiple" // Options - allows click selection of rows
        />
      </div>
    </div>
  );
};

export default HomeScreen;
