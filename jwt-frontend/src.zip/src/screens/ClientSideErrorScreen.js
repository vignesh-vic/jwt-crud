import React from "react";

const ClientSideErrorScreen = () => {
  return (
    <div>
      <h1>Client Side Error</h1>
    </div>
  );
};

export default ClientSideErrorScreen;
