import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomeScreen from "./screens/HomeScreen";
import ClientSideErrorScreen from "./screens/ClientSideErrorScreen";
import Login from "./auth/Login";
import Register from "./auth/Register";

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<div>Home Screen</div>} />
        <Route path="/userData" Component={HomeScreen} />
        <Route path="/login" Component={Login} />
        <Route path="/register" Component={Register} />
        <Route path="*" element={<ClientSideErrorScreen />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
